module top(input a,output y);assign y = ;endmodule
