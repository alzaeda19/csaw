# Publication status

This is the November 12 GitHub publication copy of the saved simulation package, including the subsequent documentation and AI-record recovery addendum. **Start with [CURRENT_GUIDE.md](CURRENT_GUIDE.md)** for the improved explanation and exact remaining gaps. Original README/handoff statements that nothing has been uploaded, and the original AI index's earlier export cutoff, describe the prior packaging stage. See the repository commit and publication receipt for upload status.

All 262 original files, including source, testbenches, logs and MANIFEST.json, remain byte-identical. PUBLICATION_MANIFEST.json additionally covers this note, the current guide, explanation/recovery supplements, publication review and upstream notices. No new simulations were run and no new simulation results are implied by the new ZIP hash. Static analysis and record-integrity checks are separately labeled.

GitHub is the submission destination specified by the user. Collaborators were deliberately skipped at the user's request. The user subsequently authorized public visibility, including AI records and local paths. Public viewing requires no collaborator invitation. Instructor receipt/acceptance and full rubric satisfaction are not established. The original assignment remains the grading basis.

To use the original reproduction directions, extract the ZIP outside a Git checkout; the archived runner deliberately refuses to write in a Git repository.
